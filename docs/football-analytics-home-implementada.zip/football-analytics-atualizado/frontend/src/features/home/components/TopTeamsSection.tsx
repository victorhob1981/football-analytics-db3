"use client";

import Link from "next/link";

import { SparklineChart } from "@/shared/components/charts/SparklineChart";
import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { formatNumber } from "@/shared/utils/formatters";
import { useTopTeams } from "@/features/home/hooks";
import type { TeamStrengthItem } from "@/features/home/types";

function TeamRow({
  team,
  rank,
  metricLabel,
  color,
}: {
  team: TeamStrengthItem;
  rank: number;
  metricLabel: string;
  color: string;
}) {
  return (
    <li className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50 px-3 py-2 transition-colors hover:bg-slate-100">
      <span className="w-5 text-center text-xs font-semibold text-slate-400">{rank}</span>
      <Link
        className="min-w-0 flex-1 truncate text-sm font-medium text-slate-800 no-underline hover:text-emerald-700"
        href={`/clubs/${team.teamId}`}
      >
        {team.teamName}
      </Link>
      {team.trend && team.trend.length > 1 ? (
        <div className="w-16 shrink-0">
          <SparklineChart
            color={color}
            data={team.trend}
            dataKey="value"
            height={28}
            showTooltip={false}
          />
        </div>
      ) : null}
      <span className="shrink-0 text-sm font-semibold text-slate-900">
        {formatNumber(team.value)}
      </span>
      <span className="hidden shrink-0 text-xs text-slate-400 sm:block">{metricLabel}</span>
    </li>
  );
}

function ColumnSkeleton() {
  return (
    <div className="space-y-2">
      <LoadingSkeleton height={16} width="50%" />
      {Array.from({ length: 5 }).map((_, i) => (
        <LoadingSkeleton height={44} key={i} />
      ))}
    </div>
  );
}

export function TopTeamsSection() {
  const { data, isLoading, isEmpty } = useTopTeams();

  if (isLoading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2">
        <ColumnSkeleton />
        <ColumnSkeleton />
      </div>
    );
  }

  if (isEmpty || !data) {
    return (
      <EmptyState
        description="Dados de ataques e defesas não disponíveis para o recorte atual."
        title="Sem dados de times"
      />
    );
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2">
      {/* Top Attacks */}
      <div className="space-y-2">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-700">
          <span className="inline-block h-2.5 w-2.5 rounded-full bg-emerald-500" />
          Melhores Ataques
        </h3>
        <ul className="space-y-1.5">
          {data.topAttacks.map((team, i) => (
            <TeamRow
              color="#16a34a"
              key={team.teamId}
              metricLabel="gols"
              rank={i + 1}
              team={team}
            />
          ))}
        </ul>
      </div>

      {/* Top Defenses */}
      <div className="space-y-2">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-700">
          <span className="inline-block h-2.5 w-2.5 rounded-full bg-sky-500" />
          Melhores Defesas
        </h3>
        <ul className="space-y-1.5">
          {data.topDefenses.map((team, i) => (
            <TeamRow
              color="#0369a1"
              key={team.teamId}
              metricLabel="sofridos"
              rank={i + 1}
              team={team}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}
