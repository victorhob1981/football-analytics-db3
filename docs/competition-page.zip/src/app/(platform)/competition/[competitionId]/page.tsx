"use client";

import { useState } from "react";

import {
  EvolutionChart,
  RoundCalendar,
  RoundNavigator,
  StageFilter,
  StandingsTable,
} from "@/features/competition/components";
import {
  useRoundCalendar,
  useRounds,
  useStages,
  useStandingsEvolution,
  useStandingsSnapshot,
} from "@/features/competition/hooks";

// ─── Section shell ────────────────────────────────────────────────────────────

function SectionShell({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="space-y-3">
      <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
        {title}
      </h2>
      {children}
    </section>
  );
}

// ─── Page component ───────────────────────────────────────────────────────────

type CompetitionPageProps = {
  params: Promise<{ competitionId: string }>;
};

export default function CompetitionPage({ params }: CompetitionPageProps) {
  // Next.js 15 passes params as a Promise — unwrap with React.use()
  // For client components we receive it directly after layout unwraps it,
  // but since this is a leaf client page we use the pattern below:
  const { competitionId } = (params as unknown as { competitionId: string });

  // ── Local state ────────────────────────────────────────────────────────────
  const [selectedRoundId, setSelectedRoundId] = useState<string | null>(null);
  const [selectedStageId, setSelectedStageId] = useState<string | null>(null);

  const localFilters = {
    ...(selectedStageId ? { stageId: selectedStageId } : {}),
    // When user picks a round locally, it overrides the global roundId for
    // snapshot + calendar (evolution always shows the full arc).
    ...(selectedRoundId ? { roundId: selectedRoundId } : {}),
  };

  // ── Data fetching ──────────────────────────────────────────────────────────
  const roundsQuery = useRounds(competitionId);
  const stagesQuery = useStages(competitionId);
  const snapshotQuery = useStandingsSnapshot(competitionId, localFilters);
  const evolutionQuery = useStandingsEvolution(competitionId, {
    ...(selectedStageId ? { stageId: selectedStageId } : {}),
  });
  const calendarQuery = useRoundCalendar(competitionId, localFilters);

  // ── Auto-select current round on first load ────────────────────────────────
  const rounds = roundsQuery.data ?? [];
  if (selectedRoundId === null && rounds.length > 0) {
    const current = rounds.find((r) => r.isCurrentRound) ?? rounds[rounds.length - 1];
    if (current) setSelectedRoundId(current.roundId);
  }

  const snapshot = snapshotQuery.data;
  const calendar = calendarQuery.data;
  const evolution = evolutionQuery.data;

  return (
    <div className="space-y-8">
      {/* ── Page header ──────────────────────────────────────────────────── */}
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
            Competição
          </h1>
          <p className="mt-0.5 text-sm text-slate-500">
            Classificação, evolução e calendário por rodada
          </p>
        </div>

        {/* Stage filter — top-right, aligned with header */}
        <StageFilter
          loading={stagesQuery.isLoading}
          onSelect={setSelectedStageId}
          selectedStageId={selectedStageId}
          stages={stagesQuery.data ?? []}
        />
      </header>

      {/* ── Seção 1: Navegador de rodadas ─────────────────────────────────── */}
      <SectionShell title="Rodadas">
        <RoundNavigator
          loading={roundsQuery.isLoading}
          onSelect={setSelectedRoundId}
          rounds={rounds}
          selectedRoundId={selectedRoundId}
        />
      </SectionShell>

      {/* ── Seção 2: Classificação snapshot ──────────────────────────────── */}
      <SectionShell title="Classificação">
        <StandingsTable
          coverage={snapshotQuery.coverage}
          isPartial={snapshotQuery.isPartial}
          loading={snapshotQuery.isLoading}
          roundLabel={snapshot?.roundLabel}
          rows={snapshot?.rows ?? []}
        />
      </SectionShell>

      {/* ── Seção 3: Evolução (pontos / posição) ─────────────────────────── */}
      <SectionShell title="Evolução da Classificação">
        <EvolutionChart
          data={evolution}
          loading={evolutionQuery.isLoading}
        />
      </SectionShell>

      {/* ── Seção 4: Calendário da rodada ────────────────────────────────── */}
      <SectionShell title="Partidas da Rodada">
        <RoundCalendar
          loading={calendarQuery.isLoading}
          matches={calendar?.matches ?? []}
          roundLabel={calendar?.roundLabel}
        />
      </SectionShell>
    </div>
  );
}
