import { useQueryWithCoverage } from "@/shared/hooks/useQueryWithCoverage";

import { competitionQueryKeys } from "@/features/competition/queryKeys";
import { fetchRoundCalendar } from "@/features/competition/services";
import type {
  CompetitionLocalFilters,
  RoundCalendarData,
} from "@/features/competition/types";
import { useCompetitionFilters } from "./useCompetitionFilters";

const STALE_TIME_MS = 5 * 60 * 1000;
const GC_TIME_MS = 15 * 60 * 1000;

export function useRoundCalendar(
  competitionId: string,
  localFilters: CompetitionLocalFilters = {},
) {
  const globalFilters = useCompetitionFilters();
  const mergedFilters = { ...globalFilters, ...localFilters };

  return useQueryWithCoverage<RoundCalendarData>({
    queryKey: competitionQueryKeys.calendar(competitionId, mergedFilters),
    queryFn: () => fetchRoundCalendar(competitionId, mergedFilters),
    enabled: competitionId.length > 0,
    staleTime: STALE_TIME_MS,
    gcTime: GC_TIME_MS,
    isDataEmpty: (data) => data.matches.length === 0,
  });
}
