export {
  COMPETITION_ENDPOINTS,
  fetchRoundCalendar,
  fetchRounds,
  fetchStages,
  fetchStandingsEvolution,
  fetchStandingsSnapshot,
} from "./competition.service";
