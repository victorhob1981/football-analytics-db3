"use client";

import Link from "next/link";

import { PartialDataBanner } from "@/shared/components/coverage/PartialDataBanner";
import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import type { StandingRow, StandingZone } from "@/features/competition/types";
import type { CoverageState } from "@/shared/types/coverage.types";

// ─── Zone config ──────────────────────────────────────────────────────────────

const ZONE_CONFIG: Record<
  NonNullable<StandingZone>,
  { bar: string; label: string }
> = {
  title: { bar: "bg-amber-400", label: "Título" },
  continental: { bar: "bg-emerald-500", label: "Continental" },
  relegation: { bar: "bg-rose-500", label: "Rebaixamento" },
};

// ─── Form badge ───────────────────────────────────────────────────────────────

const FORM_CONFIG: Record<string, { bg: string; text: string }> = {
  W: { bg: "bg-emerald-500", text: "text-white" },
  D: { bg: "bg-slate-300", text: "text-slate-700" },
  L: { bg: "bg-rose-500", text: "text-white" },
};

function FormBadge({ result }: { result: string }) {
  const cfg = FORM_CONFIG[result] ?? { bg: "bg-slate-200", text: "text-slate-500" };
  return (
    <span
      aria-label={result === "W" ? "Vitória" : result === "D" ? "Empate" : "Derrota"}
      className={`inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold ${cfg.bg} ${cfg.text}`}
    >
      {result}
    </span>
  );
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function StandingsSkeleton() {
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <div className="border-b border-slate-100 bg-slate-50 px-4 py-2.5">
        <LoadingSkeleton height={12} width="30%" />
      </div>
      <div className="divide-y divide-slate-100">
        {Array.from({ length: 10 }).map((_, i) => (
          <div className="flex items-center gap-3 px-4 py-3" key={i}>
            <LoadingSkeleton height={12} width={20} />
            <LoadingSkeleton height={14} width="35%" />
            <div className="ml-auto flex gap-4">
              {Array.from({ length: 7 }).map((__, j) => (
                <LoadingSkeleton height={12} key={j} width={24} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

type StandingsTableProps = {
  rows: StandingRow[];
  roundLabel?: string;
  loading?: boolean;
  isPartial?: boolean;
  coverage?: CoverageState;
};

export function StandingsTable({
  rows,
  roundLabel,
  loading = false,
  isPartial = false,
  coverage,
}: StandingsTableProps) {
  if (loading) return <StandingsSkeleton />;

  if (rows.length === 0) {
    return (
      <EmptyState
        description="Snapshot de classificação indisponível para esta rodada."
        title="Sem dados de classificação"
      />
    );
  }

  const coverageForBanner = coverage ?? { status: "partial" as const };

  return (
    <div className="space-y-2">
      {isPartial ? <PartialDataBanner coverage={coverageForBanner} /> : null}

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        {/* Caption */}
        {roundLabel ? (
          <div className="border-b border-slate-100 bg-slate-50 px-4 py-2">
            <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
              Classificação — {roundLabel}
            </p>
          </div>
        ) : null}

        {/* Zone legend */}
        <div className="flex flex-wrap gap-3 border-b border-slate-100 px-4 py-2">
          {Object.entries(ZONE_CONFIG).map(([zone, cfg]) => (
            <div className="flex items-center gap-1.5" key={zone}>
              <span className={`h-2.5 w-2.5 rounded-full ${cfg.bar}`} />
              <span className="text-xs text-slate-500">{cfg.label}</span>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-semibold uppercase tracking-wide text-slate-400">
                <th className="py-2.5 pl-4 pr-2 w-8">#</th>
                <th className="py-2.5 pr-3 min-w-[140px]">Time</th>
                <th className="py-2.5 pr-3 text-center">J</th>
                <th className="py-2.5 pr-3 text-center">V</th>
                <th className="py-2.5 pr-3 text-center">E</th>
                <th className="py-2.5 pr-3 text-center">D</th>
                <th className="py-2.5 pr-3 text-center">GP</th>
                <th className="py-2.5 pr-3 text-center">GC</th>
                <th className="py-2.5 pr-3 text-center">SG</th>
                <th className="py-2.5 pr-3 text-right font-bold text-slate-600">P</th>
                <th className="hidden py-2.5 pr-4 sm:table-cell">Forma</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const zoneCfg = row.zone ? ZONE_CONFIG[row.zone] : null;

                return (
                  <tr
                    className="group border-b border-slate-100 last:border-0 hover:bg-slate-50"
                    key={row.teamId}
                  >
                    {/* Position + zone indicator */}
                    <td className="relative py-3 pl-4 pr-2">
                      {zoneCfg ? (
                        <span
                          aria-label={zoneCfg.label}
                          className={`absolute inset-y-0 left-0 w-1 ${zoneCfg.bar}`}
                        />
                      ) : null}
                      <span className="text-sm font-semibold text-slate-500">
                        {row.position}
                      </span>
                    </td>

                    {/* Team name */}
                    <td className="py-3 pr-3">
                      <Link
                        className="text-sm font-medium text-slate-800 no-underline hover:text-emerald-700"
                        href={`/clubs/${row.teamId}`}
                      >
                        {row.teamName}
                      </Link>
                    </td>

                    {/* Stats */}
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">{row.played}</td>
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">{row.won}</td>
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">{row.drawn}</td>
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">{row.lost}</td>
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">{row.goalsFor}</td>
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">{row.goalsAgainst}</td>
                    <td className="py-3 pr-3 text-center text-sm tabular-nums text-slate-600">
                      {row.goalDiff > 0 ? `+${row.goalDiff}` : row.goalDiff}
                    </td>

                    {/* Points */}
                    <td className="py-3 pr-3 text-right text-sm font-bold text-slate-900 tabular-nums">
                      {row.points}
                    </td>

                    {/* Form */}
                    <td className="hidden py-3 pr-4 sm:table-cell">
                      {row.form && row.form.length > 0 ? (
                        <div className="flex items-center gap-1">
                          {row.form.slice(-5).map((result, i) => (
                            <FormBadge key={i} result={result} />
                          ))}
                        </div>
                      ) : (
                        <span className="text-xs text-slate-300">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
