"use client";

import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import type { RoundItem } from "@/features/competition/types";

type RoundNavigatorProps = {
  rounds: RoundItem[];
  selectedRoundId: string | null;
  onSelect: (roundId: string) => void;
  loading?: boolean;
};

export function RoundNavigator({
  rounds,
  selectedRoundId,
  onSelect,
  loading = false,
}: RoundNavigatorProps) {
  if (loading) {
    return (
      <div className="flex gap-2 overflow-x-auto pb-1">
        {Array.from({ length: 10 }).map((_, i) => (
          <LoadingSkeleton
            className="shrink-0"
            height={32}
            key={i}
            rounded="full"
            width={56}
          />
        ))}
      </div>
    );
  }

  if (rounds.length === 0) {
    return (
      <p className="text-sm text-slate-400">Nenhuma rodada disponível.</p>
    );
  }

  return (
    <div
      aria-label="Navegador de rodadas"
      className="flex gap-1.5 overflow-x-auto pb-1"
      role="group"
    >
      {rounds.map((round) => {
        const isSelected = round.roundId === selectedRoundId;
        const isCurrent = round.isCurrentRound && !isSelected;

        return (
          <button
            aria-current={isSelected ? "true" : undefined}
            aria-label={`Rodada ${round.roundNumber}${round.isCurrentRound ? " (rodada atual)" : ""}`}
            className={[
              "shrink-0 rounded-full border px-3 py-1 text-xs font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-300 focus:ring-offset-1",
              isSelected
                ? "border-emerald-600 bg-emerald-600 text-white"
                : isCurrent
                  ? "border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                  : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50",
            ]
              .filter(Boolean)
              .join(" ")}
            key={round.roundId}
            onClick={() => onSelect(round.roundId)}
            type="button"
          >
            R{round.roundNumber}
          </button>
        );
      })}
    </div>
  );
}
