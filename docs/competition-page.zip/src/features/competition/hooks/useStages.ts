import { useQueryWithCoverage } from "@/shared/hooks/useQueryWithCoverage";

import { competitionQueryKeys } from "@/features/competition/queryKeys";
import { fetchStages } from "@/features/competition/services";
import type { StageItem } from "@/features/competition/types";
import { useCompetitionFilters } from "./useCompetitionFilters";

const STALE_TIME_MS = 60 * 60 * 1000;
const GC_TIME_MS = 2 * 60 * 60 * 1000;

export function useStages(competitionId: string) {
  const filters = useCompetitionFilters();

  return useQueryWithCoverage<StageItem[]>({
    queryKey: competitionQueryKeys.stages(competitionId, filters),
    queryFn: () => fetchStages(competitionId, filters),
    enabled: competitionId.length > 0,
    staleTime: STALE_TIME_MS,
    gcTime: GC_TIME_MS,
    isDataEmpty: (data) => data.length === 0,
  });
}
