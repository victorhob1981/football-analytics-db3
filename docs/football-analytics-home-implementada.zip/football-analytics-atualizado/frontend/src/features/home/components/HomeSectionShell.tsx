import type { ReactNode } from "react";

type HomeSectionShellProps = {
  title: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
  action?: ReactNode;
};

export function HomeSectionShell({
  title,
  subtitle,
  children,
  className,
  action,
}: HomeSectionShellProps) {
  const base = [
    "rounded-xl border border-slate-200 bg-white p-5 shadow-sm",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <section className={base}>
      <header className="mb-4 flex items-start justify-between gap-2">
        <div className="space-y-0.5">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-500">
            {title}
          </h2>
          {subtitle ? (
            <p className="text-xs text-slate-400">{subtitle}</p>
          ) : null}
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </header>
      {children}
    </section>
  );
}
