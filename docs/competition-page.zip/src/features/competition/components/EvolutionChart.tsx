"use client";

import { useState } from "react";

import { LineChart } from "@/shared/components/charts/LineChart";
import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import type { EvolutionMetric, StandingsEvolutionData } from "@/features/competition/types";

const TEAM_COLORS = [
  "#15803d", "#0369a1", "#7c3aed", "#dc2626",
  "#d97706", "#0f766e", "#be185d", "#1d4ed8",
];

type EvolutionChartProps = {
  data: StandingsEvolutionData | undefined;
  loading?: boolean;
};

export function EvolutionChart({ data, loading = false }: EvolutionChartProps) {
  const [metric, setMetric] = useState<EvolutionMetric>("points");

  if (loading) {
    return (
      <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-4">
        <div className="flex justify-between">
          <LoadingSkeleton height={14} width="30%" />
          <LoadingSkeleton height={28} width={160} />
        </div>
        <LoadingSkeleton height={300} />
      </div>
    );
  }

  if (!data || data.series.length === 0) {
    return (
      <EmptyState
        description="Evolução de classificação indisponível para o recorte atual."
        title="Sem dados de evolução"
      />
    );
  }

  const lines = data.teamNames.map((name, i) => ({
    dataKey: name,
    label: name,
    color: TEAM_COLORS[i % TEAM_COLORS.length],
  }));

  return (
    <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-4">
      {/* Header + toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
          {metric === "points" ? "Pontos acumulados por rodada" : "Posição por rodada"}
        </p>
        <div
          aria-label="Métrica do gráfico"
          className="flex rounded-lg border border-slate-200 bg-slate-50 p-0.5"
          role="group"
        >
          {(["points", "position"] as EvolutionMetric[]).map((m) => (
            <button
              aria-pressed={metric === m}
              className={[
                "rounded-md px-3 py-1 text-xs font-medium transition-colors",
                metric === m
                  ? "bg-white text-slate-800 shadow-sm"
                  : "text-slate-500 hover:text-slate-700",
              ].join(" ")}
              key={m}
              onClick={() => setMetric(m)}
              type="button"
            >
              {m === "points" ? "Pontos" : "Posição"}
            </button>
          ))}
        </div>
      </div>

      <LineChart
        data={data.series}
        height={300}
        lines={lines}
        showLegend
        xKey="roundLabel"
        yAxisMetricKey={metric}
      />
    </div>
  );
}
