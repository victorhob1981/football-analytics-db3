import { useMemo } from "react";

import { useGlobalFiltersState } from "@/shared/hooks/useGlobalFilters";
import { useTimeRange } from "@/shared/hooks/useTimeRange";

import type { CompetitionGlobalFilters } from "@/features/competition/types";

export function useCompetitionFilters(): CompetitionGlobalFilters {
  const { competitionId, seasonId, venue } = useGlobalFiltersState();
  const { params } = useTimeRange();

  return useMemo<CompetitionGlobalFilters>(
    () => ({
      competitionId,
      seasonId,
      venue,
      roundId: params.roundId,
      lastN: params.lastN,
      dateRangeStart: params.dateRangeStart,
      dateRangeEnd: params.dateRangeEnd,
    }),
    [competitionId, seasonId, venue, params],
  );
}
