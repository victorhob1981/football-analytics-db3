import type { ApiResponse } from "@/shared/types/api-response.types";
import { apiRequest, type QueryParams } from "@/shared/services/api-client";

import type {
  CompetitionGlobalFilters,
  CompetitionLocalFilters,
  RoundCalendarData,
  RoundItem,
  StageItem,
  StandingsEvolutionData,
  StandingsSnapshotData,
} from "@/features/competition/types";

export const COMPETITION_ENDPOINTS = {
  rounds: (competitionId: string) => `/api/v1/competition/${competitionId}/rounds`,
  stages: (competitionId: string) => `/api/v1/competition/${competitionId}/stages`,
  standings: (competitionId: string) => `/api/v1/competition/${competitionId}/standings`,
  evolution: (competitionId: string) => `/api/v1/competition/${competitionId}/evolution`,
  roundCalendar: (competitionId: string) => `/api/v1/competition/${competitionId}/calendar`,
} as const;

function toQueryParams(
  filters: CompetitionGlobalFilters & CompetitionLocalFilters,
): QueryParams {
  const params: QueryParams = {};

  for (const [key, value] of Object.entries(
    filters as Record<string, unknown>,
  )) {
    if (value === null || value === undefined) continue;
    if (typeof value === "string" && value.trim().length === 0) continue;
    if (key === "venue" && value === "all") continue;

    const normalizedKey =
      key === "dateRangeStart"
        ? "dateStart"
        : key === "dateRangeEnd"
          ? "dateEnd"
          : key;
    params[normalizedKey] = value as string | number | boolean;
  }

  return params;
}

export async function fetchRounds(
  competitionId: string,
  filters: CompetitionGlobalFilters = {},
): Promise<ApiResponse<RoundItem[]>> {
  return apiRequest<ApiResponse<RoundItem[]>>(
    COMPETITION_ENDPOINTS.rounds(competitionId),
    { method: "GET", params: toQueryParams(filters) },
  );
}

export async function fetchStages(
  competitionId: string,
  filters: CompetitionGlobalFilters = {},
): Promise<ApiResponse<StageItem[]>> {
  return apiRequest<ApiResponse<StageItem[]>>(
    COMPETITION_ENDPOINTS.stages(competitionId),
    { method: "GET", params: toQueryParams(filters) },
  );
}

export async function fetchStandingsSnapshot(
  competitionId: string,
  filters: CompetitionGlobalFilters & CompetitionLocalFilters = {},
): Promise<ApiResponse<StandingsSnapshotData>> {
  return apiRequest<ApiResponse<StandingsSnapshotData>>(
    COMPETITION_ENDPOINTS.standings(competitionId),
    { method: "GET", params: toQueryParams(filters) },
  );
}

export async function fetchStandingsEvolution(
  competitionId: string,
  filters: CompetitionGlobalFilters & CompetitionLocalFilters = {},
): Promise<ApiResponse<StandingsEvolutionData>> {
  return apiRequest<ApiResponse<StandingsEvolutionData>>(
    COMPETITION_ENDPOINTS.evolution(competitionId),
    { method: "GET", params: toQueryParams(filters) },
  );
}

export async function fetchRoundCalendar(
  competitionId: string,
  filters: CompetitionGlobalFilters & CompetitionLocalFilters = {},
): Promise<ApiResponse<RoundCalendarData>> {
  return apiRequest<ApiResponse<RoundCalendarData>>(
    COMPETITION_ENDPOINTS.roundCalendar(competitionId),
    { method: "GET", params: toQueryParams(filters) },
  );
}
