import { ChevronDown, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type TimeRangeType = "season" | "lastN" | "month" | "interval";

export interface GlobalFilters {
  competition: string;
  season: string;
  timeRange: TimeRangeType;
  lastN?: number;
  month?: string;
  startDate?: string;
  endDate?: string;
}

interface GlobalFilterBarProps {
  filters: GlobalFilters;
  onFiltersChange: (filters: GlobalFilters) => void;
}

export function GlobalFilterBar({ filters, onFiltersChange }: GlobalFilterBarProps) {
  const handleCompetitionChange = (value: string) => {
    onFiltersChange({ ...filters, competition: value });
  };

  const handleSeasonChange = (value: string) => {
    onFiltersChange({ ...filters, season: value });
  };

  const handleTimeRangeChange = (value: TimeRangeType) => {
    onFiltersChange({ ...filters, timeRange: value });
  };

  const handleLastNChange = (value: string) => {
    onFiltersChange({ ...filters, lastN: parseInt(value) });
  };

  return (
    <div className="sticky top-0 z-40 border-b border-slate-200 bg-white shadow-sm">
      <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center gap-4">
          {/* Competição */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-600">Competição</label>
            <Select value={filters.competition} onValueChange={handleCompetitionChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Selecione uma competição" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="serie-a">Série A 2024</SelectItem>
                <SelectItem value="serie-b">Série B 2024</SelectItem>
                <SelectItem value="copa-br">Copa do Brasil 2024</SelectItem>
                <SelectItem value="libertadores">Libertadores 2024</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Temporada */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-600">Temporada</label>
            <Select value={filters.season} onValueChange={handleSeasonChange}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Selecione a temporada" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Recorte Temporal */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-600">Recorte</label>
            <Select value={filters.timeRange} onValueChange={(v) => handleTimeRangeChange(v as TimeRangeType)}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Selecione o recorte" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="season">Temporada Completa</SelectItem>
                <SelectItem value="lastN">Últimos N Jogos</SelectItem>
                <SelectItem value="month">Por Mês</SelectItem>
                <SelectItem value="interval">Intervalo Customizado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Últimos N Jogos (condicional) */}
          {filters.timeRange === "lastN" && (
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-slate-600">Últimos N</label>
              <Select value={String(filters.lastN || 10)} onValueChange={handleLastNChange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">Últimos 5</SelectItem>
                  <SelectItem value="10">Últimos 10</SelectItem>
                  <SelectItem value="15">Últimos 15</SelectItem>
                  <SelectItem value="20">Últimos 20</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Mês (condicional) */}
          {filters.timeRange === "month" && (
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-slate-600">Mês</label>
              <Select value={filters.month || "2024-01"} onValueChange={(value) => onFiltersChange({ ...filters, month: value })}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024-01">Janeiro 2024</SelectItem>
                  <SelectItem value="2024-02">Fevereiro 2024</SelectItem>
                  <SelectItem value="2024-03">Março 2024</SelectItem>
                  <SelectItem value="2024-04">Abril 2024</SelectItem>
                  <SelectItem value="2024-05">Maio 2024</SelectItem>
                  <SelectItem value="2024-06">Junho 2024</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Intervalo (condicional) */}
          {filters.timeRange === "interval" && (
            <>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-slate-600">De</label>
                <input
                  type="date"
                  value={filters.startDate || "2024-01-01"}
                  onChange={(e) => onFiltersChange({ ...filters, startDate: e.target.value })}
                  className="rounded-md border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-slate-600">Até</label>
                <input
                  type="date"
                  value={filters.endDate || "2024-12-31"}
                  onChange={(e) => onFiltersChange({ ...filters, endDate: e.target.value })}
                  className="rounded-md border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
