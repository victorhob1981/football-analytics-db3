import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Trophy, Target, Users, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { GlobalFilterBar, type GlobalFilters } from "@/components/GlobalFilterBar";
import { InsightFeed, type Insight } from "@/components/InsightFeed";
import { CoveragePanel, type CoverageIndicator } from "@/components/CoveragePanel";
import { Sparkline } from "@/components/Sparkline";
import { Button } from "@/components/ui/button";

/**
 * Design Philosophy: Esportivo Premium com Tema Escuro
 * Página Home Executiva - Leitura rápida do campeonato
 * Manual: §5.1, §15
 */

const mockKPIData = {
  totalMatches: 380,
  totalGoals: 1247,
  avgGoalsPerMatch: 3.28,
  totalTeams: 42,
};

const mockTeamsData = [
  {
    id: "team-1",
    name: "Time A",
    goalsFor: 85,
    goalsAgainst: 32,
    sparkline: [
      { value: 5 },
      { value: 7 },
      { value: 6 },
      { value: 8 },
      { value: 9 },
      { value: 8 },
    ],
  },
  {
    id: "team-2",
    name: "Time B",
    goalsFor: 78,
    goalsAgainst: 38,
    sparkline: [
      { value: 4 },
      { value: 5 },
      { value: 6 },
      { value: 7 },
      { value: 7 },
      { value: 8 },
    ],
  },
  {
    id: "team-3",
    name: "Time C",
    goalsFor: 72,
    goalsAgainst: 41,
    sparkline: [
      { value: 3 },
      { value: 4 },
      { value: 5 },
      { value: 6 },
      { value: 6 },
      { value: 7 },
    ],
  },
];

const mockStandingsData = [
  { round: 1, "Time A": 3, "Time B": 1, "Time C": 0, "Time D": 1, "Time E": 0, "Time F": 2 },
  { round: 2, "Time A": 6, "Time B": 4, "Time C": 3, "Time D": 3, "Time E": 1, "Time F": 5 },
  { round: 3, "Time A": 9, "Time B": 7, "Time C": 6, "Time D": 6, "Time E": 4, "Time F": 8 },
  { round: 4, "Time A": 12, "Time B": 10, "Time C": 9, "Time D": 9, "Time E": 7, "Time F": 11 },
  { round: 5, "Time A": 15, "Time B": 13, "Time C": 12, "Time D": 12, "Time E": 10, "Time F": 14 },
  { round: 6, "Time A": 18, "Time B": 16, "Time C": 15, "Time D": 15, "Time E": 13, "Time F": 17 },
];

const mockPlayersData = [
  { id: "p1", name: "Jogador A", club: "Time A", goals: 24, assists: 8, rating: 8.2, variation: 2.1 },
  { id: "p2", name: "Jogador B", club: "Time B", goals: 21, assists: 6, rating: 7.9, variation: 1.5 },
  { id: "p3", name: "Jogador C", club: "Time C", goals: 18, assists: 10, rating: 7.6, variation: -0.3 },
  { id: "p4", name: "Jogador D", club: "Time D", goals: 16, assists: 7, rating: 7.3, variation: 0.8 },
  { id: "p5", name: "Jogador E", club: "Time E", goals: 14, assists: 9, rating: 7.1, variation: 1.2 },
];

const mockInsights: Insight[] = [
  {
    id: "i1",
    severity: "critical",
    title: "Queda ofensiva detectada",
    description: "Time A reduziu média de gols em 35% nas últimas 3 rodadas",
    timestamp: "Há 2 horas",
    action: { label: "Ver análise", href: "/clubs/team-a" },
  },
  {
    id: "i2",
    severity: "warning",
    title: "Outlier de performance",
    description: "Jogador B com 3 gols em um único jogo (acima da média histórica)",
    timestamp: "Há 4 horas",
    action: { label: "Ver perfil", href: "/players/p2" },
  },
  {
    id: "i3",
    severity: "info",
    title: "Tendência de pontos",
    description: "Média de gols por jogo em alta: 3.28 (vs 3.12 na rodada anterior)",
    timestamp: "Há 6 horas",
  },
  {
    id: "i4",
    severity: "warning",
    title: "Qualidade de dados",
    description: "3 partidas sem dados de lineups completos",
    timestamp: "Há 8 horas",
  },
];

const mockCoverageData: CoverageIndicator[] = [
  { label: "Fixtures com eventos", percentage: 95, description: "Dados de eventos registrados" },
  { label: "Player stats", percentage: 87, description: "Estatísticas individuais" },
  { label: "Lineups", percentage: 92, description: "Escalações completas" },
  { label: "Team stats", percentage: 78, description: "Estatísticas de times" },
];

function KPICard({ title, value, icon: Icon, color, isLoading }: any) {
  if (isLoading) {
    return (
      <div className="stat-card">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="h-4 w-24 animate-pulse rounded bg-slate-700" />
            <div className="mt-3 h-8 w-16 animate-pulse rounded bg-slate-700" />
          </div>
          <div className="h-10 w-10 animate-pulse rounded-lg bg-slate-700" />
        </div>
      </div>
    );
  }

  return (
    <div
      className="stat-card hover-lift"
      style={{
        borderLeftColor: color,
      }}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-400">{title}</p>
          <p className="mt-2 text-3xl font-bold text-slate-100">{value}</p>
        </div>
        <div className="rounded-lg p-2" style={{ backgroundColor: `${color}20` }}>
          <Icon size={24} style={{ color }} />
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const [filters, setFilters] = useState<GlobalFilters>({
    competition: "serie-a",
    season: "2024",
    timeRange: "season",
    lastN: 10,
  });

  const [isLoading] = useState(false);
  const [visibleTeams, setVisibleTeams] = useState(new Set(["Time A", "Time B", "Time C", "Time D", "Time E", "Time F"]));

  const toggleTeamVisibility = (teamName: string) => {
    const newVisible = new Set(visibleTeams);
    if (newVisible.has(teamName)) {
      newVisible.delete(teamName);
    } else {
      newVisible.add(teamName);
    }
    setVisibleTeams(newVisible);
  };

  return (
    <div className="dark min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <GlobalFilterBar filters={filters} onFiltersChange={setFilters} />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="mb-4 text-2xl font-bold text-slate-100">Indicadores Principais</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KPICard
              title="Partidas Disputadas"
              value={mockKPIData.totalMatches}
              icon={Trophy}
              color="#10B981"
              isLoading={isLoading}
            />
            <KPICard
              title="Gols Marcados"
              value={mockKPIData.totalGoals}
              icon={Target}
              color="#1E40AF"
              isLoading={isLoading}
            />
            <KPICard
              title="Média de Gols/Jogo"
              value={mockKPIData.avgGoalsPerMatch}
              icon={TrendingUp}
              color="#F97316"
              isLoading={isLoading}
            />
            <KPICard
              title="Times Participantes"
              value={mockKPIData.totalTeams}
              icon={Users}
              color="#06B6D4"
              isLoading={isLoading}
            />
          </div>
        </div>

        <div className="mb-8 grid gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-sm">
            <h3 className="mb-4 text-lg font-semibold text-slate-100">Melhores Ataques</h3>
            <div className="space-y-3">
              {mockTeamsData.map((team) => (
                <div key={team.id} className="flex items-center justify-between rounded-lg bg-slate-700 p-3 hover:bg-slate-600 transition-colors">
                  <div className="flex-1">
                    <p className="font-medium text-slate-100">{team.name}</p>
                    <p className="text-sm text-slate-400">{team.goalsFor} gols</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sparkline data={team.sparkline} color="#10B981" height={24} />
                    <span className="text-lg font-bold text-slate-100">{team.goalsFor}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-sm">
            <h3 className="mb-4 text-lg font-semibold text-slate-100">Melhores Defesas</h3>
            <div className="space-y-3">
              {[...mockTeamsData].reverse().map((team) => (
                <div key={team.id} className="flex items-center justify-between rounded-lg bg-slate-700 p-3 hover:bg-slate-600 transition-colors">
                  <div className="flex-1">
                    <p className="font-medium text-slate-100">{team.name}</p>
                    <p className="text-sm text-slate-400">{team.goalsAgainst} gols sofridos</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sparkline data={team.sparkline} color="#1E40AF" height={24} />
                    <span className="text-lg font-bold text-slate-100">{team.goalsAgainst}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mb-8 rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-sm">
          <h3 className="mb-4 text-lg font-semibold text-slate-100">Evolução da Classificação</h3>
          <p className="mb-4 text-sm text-slate-400">Pontos acumulados por rodada — principais clubes</p>

          <div className="mb-4 flex flex-wrap gap-2">
            {["Time A", "Time B", "Time C", "Time D", "Time E", "Time F"].map((team) => (
              <button
                key={team}
                onClick={() => toggleTeamVisibility(team)}
                className={`rounded-full px-3 py-1 text-xs font-medium transition-all ${
                  visibleTeams.has(team)
                    ? "bg-emerald-600 text-white"
                    : "border border-slate-600 bg-slate-700 text-slate-300 hover:bg-slate-600"
                }`}
              >
                {team}
              </button>
            ))}
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={mockStandingsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="round" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1E293B",
                  border: "1px solid #334155",
                  borderRadius: "8px",
                  color: "#F1F5F9",
                }}
              />
              <Legend />
              {visibleTeams.has("Time A") && <Line type="monotone" dataKey="Time A" stroke="#10B981" strokeWidth={2} />}
              {visibleTeams.has("Time B") && <Line type="monotone" dataKey="Time B" stroke="#1E40AF" strokeWidth={2} />}
              {visibleTeams.has("Time C") && <Line type="monotone" dataKey="Time C" stroke="#F97316" strokeWidth={2} />}
              {visibleTeams.has("Time D") && <Line type="monotone" dataKey="Time D" stroke="#06B6D4" strokeWidth={2} />}
              {visibleTeams.has("Time E") && <Line type="monotone" dataKey="Time E" stroke="#EC4899" strokeWidth={2} />}
              {visibleTeams.has("Time F") && <Line type="monotone" dataKey="Time F" stroke="#8B5CF6" strokeWidth={2} />}
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="mb-8 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-slate-100">Top Jogadores</h3>
                <p className="mt-1 text-sm text-slate-400">Líderes de gols e assistências</p>
              </div>
              <Button variant="ghost" size="sm" className="text-emerald-400 hover:text-emerald-300">
                Ver todos →
              </Button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="px-4 py-3 text-left font-semibold text-slate-300">Jogador</th>
                    <th className="px-4 py-3 text-center font-semibold text-slate-300">Gols</th>
                    <th className="px-4 py-3 text-center font-semibold text-slate-300">Assistências</th>
                    <th className="px-4 py-3 text-center font-semibold text-slate-300">Rating</th>
                    <th className="px-4 py-3 text-center font-semibold text-slate-300">Var.</th>
                  </tr>
                </thead>
                <tbody>
                  {mockPlayersData.map((player) => (
                    <tr key={player.id} className="border-b border-slate-700 hover:bg-slate-700 transition-colors">
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-slate-100">{player.name}</p>
                          <p className="text-xs text-slate-400">{player.club}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className="inline-flex items-center justify-center rounded-full bg-emerald-900 w-8 h-8 font-bold text-emerald-300">
                          {player.goals}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className="inline-flex items-center justify-center rounded-full bg-blue-900 w-8 h-8 font-bold text-blue-300">
                          {player.assists}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center font-medium text-slate-100">{player.rating}</td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {player.variation > 0 ? (
                            <>
                              <ArrowUpRight size={14} className="text-emerald-400" />
                              <span className="text-emerald-400 font-medium">+{player.variation}</span>
                            </>
                          ) : (
                            <>
                              <ArrowDownRight size={14} className="text-red-400" />
                              <span className="text-red-400 font-medium">{player.variation}</span>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <div className="rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-sm">
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-slate-100">Insights da Rodada</h3>
                <p className="mt-1 text-sm text-slate-400">Alertas e tendências</p>
              </div>
              <InsightFeed insights={mockInsights} isLoading={isLoading} />
            </div>
          </div>
        </div>

        <CoveragePanel
          indicators={mockCoverageData}
          isLoading={isLoading}
          onViewDetails={() => (window.location.href = "/audit")}
        />
      </div>
    </div>
  );
}
