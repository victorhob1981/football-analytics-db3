"use client";

import { LineChart } from "@/shared/components/charts/LineChart";
import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { useStandingsEvolution } from "@/features/home/hooks";

// Colors assigned to each team series, cycling through the palette
const TEAM_COLORS = [
  "#15803d", // emerald-700
  "#0369a1", // sky-700
  "#7c3aed", // violet-600
  "#dc2626", // red-600
  "#d97706", // amber-600
  "#0f766e", // teal-700
];

export function StandingsEvolutionSection() {
  const { data, isLoading, isEmpty } = useStandingsEvolution();

  if (isLoading) {
    return (
      <div className="space-y-2 rounded-lg border border-slate-200 bg-white p-4">
        <LoadingSkeleton height={14} width="40%" />
        <LoadingSkeleton height={280} />
      </div>
    );
  }

  if (isEmpty || !data || data.series.length === 0) {
    return (
      <EmptyState
        description="Dados de evolução de pontos não disponíveis para o recorte atual."
        title="Sem dados de evolução"
      />
    );
  }

  const lines = data.teamNames.map((name, index) => ({
    dataKey: name,
    label: name,
    color: TEAM_COLORS[index % TEAM_COLORS.length],
  }));

  return (
    <LineChart
      data={data.series}
      height={300}
      lines={lines}
      showLegend={true}
      xKey="roundLabel"
      yAxisMetricKey="points"
    />
  );
}
