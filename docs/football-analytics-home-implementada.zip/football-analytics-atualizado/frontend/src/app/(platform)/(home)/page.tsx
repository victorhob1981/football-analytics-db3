"use client";

import Link from "next/link";

import {
  CoverageSummarySection,
  HomeInsightsSection,
  HomeKpiSection,
  HomeSectionShell,
  StandingsEvolutionSection,
  TopPlayersSection,
  TopTeamsSection,
} from "@/features/home/components";

export default function PlatformHomePage() {
  return (
    <div className="space-y-6">
      {/* ── Page header ──────────────────────────────────────── */}
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
            Visão Geral
          </h1>
          <p className="mt-0.5 text-sm text-slate-500">
            Resumo executivo da temporada em curso
          </p>
        </div>
        <nav aria-label="Atalhos rápidos" className="flex flex-wrap gap-2">
          {[
            { label: "Partidas", href: "/matches" },
            { label: "Rankings", href: "/rankings/player-goals" },
            { label: "Head-to-head", href: "/head-to-head" },
          ].map((item) => (
            <Link
              className="rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 no-underline transition-colors hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700"
              href={item.href}
              key={item.href}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>

      {/* ── Row 1: KPI cards (full width) ───────────────────── */}
      <HomeKpiSection />

      {/* ── Row 2: Top Teams + Insights (2-col) ─────────────── */}
      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <HomeSectionShell
          subtitle="Melhores ataques e defesas no recorte atual"
          title="Destaques de Times"
        >
          <TopTeamsSection />
        </HomeSectionShell>

        <HomeSectionShell
          subtitle="Alertas e tendências detectados automaticamente"
          title="Insights"
        >
          <HomeInsightsSection />
        </HomeSectionShell>
      </div>

      {/* ── Row 3: Standings Evolution (full width) ──────────── */}
      <HomeSectionShell
        subtitle="Pontos acumulados por rodada — principais clubes"
        title="Evolução da Classificação"
      >
        <StandingsEvolutionSection />
      </HomeSectionShell>

      {/* ── Row 4: Top Players + Coverage (2-col) ────────────── */}
      <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
        <HomeSectionShell
          subtitle="Líderes de gols e assistências no recorte selecionado"
          title="Top Jogadores"
          action={
            <Link
              className="text-xs font-medium text-emerald-700 no-underline hover:underline"
              href="/players"
            >
              Ver todos
            </Link>
          }
        >
          <TopPlayersSection />
        </HomeSectionShell>

        <HomeSectionShell
          subtitle="Qualidade e completude dos dados por módulo"
          title="Cobertura de Dados"
        >
          <CoverageSummarySection />
        </HomeSectionShell>
      </div>
    </div>
  );
}
