import { useQueryWithCoverage } from "@/shared/hooks/useQueryWithCoverage";

import { competitionQueryKeys } from "@/features/competition/queryKeys";
import { fetchStandingsEvolution } from "@/features/competition/services";
import type {
  CompetitionLocalFilters,
  StandingsEvolutionData,
} from "@/features/competition/types";
import { useCompetitionFilters } from "./useCompetitionFilters";

const STALE_TIME_MS = 10 * 60 * 1000;
const GC_TIME_MS = 20 * 60 * 1000;

export function useStandingsEvolution(
  competitionId: string,
  localFilters: CompetitionLocalFilters = {},
) {
  const globalFilters = useCompetitionFilters();
  const mergedFilters = { ...globalFilters, ...localFilters };

  return useQueryWithCoverage<StandingsEvolutionData>({
    queryKey: competitionQueryKeys.evolution(competitionId, mergedFilters),
    queryFn: () => fetchStandingsEvolution(competitionId, mergedFilters),
    enabled: competitionId.length > 0,
    staleTime: STALE_TIME_MS,
    gcTime: GC_TIME_MS,
    isDataEmpty: (data) => data.series.length === 0,
  });
}
