"use client";

import { StatCard } from "@/shared/components/data-display/StatCard";
import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { useLeagueKpi } from "@/features/home/hooks";

function KpiSkeletons() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div className="rounded-lg border border-slate-200 bg-white p-4" key={i}>
          <LoadingSkeleton height={14} width="60%" />
          <LoadingSkeleton className="mt-2" height={32} width="40%" />
        </div>
      ))}
    </div>
  );
}

export function HomeKpiSection() {
  const { data, isLoading, isEmpty } = useLeagueKpi();

  if (isLoading) return <KpiSkeletons />;

  if (isEmpty || !data) {
    return (
      <EmptyState
        description="Nenhum KPI disponível para o recorte atual."
        title="Sem dados de temporada"
      />
    );
  }

  const cards = [
    { title: "Partidas disputadas", value: data.totalMatches, metricKey: "matches" },
    { title: "Gols marcados", value: data.totalGoals, metricKey: "goals" },
    { title: "Média de gols/jogo", value: data.avgGoalsPerMatch, metricKey: "avg_goals_per_match" },
    { title: "Times participantes", value: data.totalTeams, metricKey: "teams" },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {cards.map((card) => (
        <StatCard
          description={undefined}
          footer={undefined}
          key={card.title}
          metricKey={card.metricKey}
          title={card.title}
          value={card.value}
        />
      ))}
    </div>
  );
}
