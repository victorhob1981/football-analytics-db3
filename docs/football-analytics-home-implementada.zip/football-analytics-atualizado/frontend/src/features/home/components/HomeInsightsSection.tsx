"use client";

import { getHighestInsightSeverity, InsightBadge, InsightFeed } from "@/features/insights/components";
import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { useGlobalFiltersState } from "@/shared/hooks/useGlobalFilters";
import { useInsights } from "@/shared/hooks/useInsights";

export function HomeInsightsSection() {
  const { competitionId } = useGlobalFiltersState();
  const entityType = competitionId ? "competition" : "global";

  const { data: insights, isLoading, isEmpty } = useInsights({
    entityType,
    entityId: competitionId ?? null,
  });

  const list = insights ?? [];
  const highestSeverity = getHighestInsightSeverity(list);

  if (isLoading) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <LoadingSkeleton height={96} key={i} />
        ))}
      </div>
    );
  }

  if (isEmpty || list.length === 0) {
    return (
      <EmptyState
        description="Nenhum insight disponível para o contexto atual da temporada."
        title="Sem insights"
      />
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <InsightBadge count={list.length} highestSeverity={highestSeverity} />
        <span className="text-xs text-slate-400">ordenados por severidade</span>
      </div>
      <InsightFeed insights={list} title="" />
    </div>
  );
}
