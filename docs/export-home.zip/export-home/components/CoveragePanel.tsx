import { BarChart3, Link as LinkIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface CoverageIndicator {
  label: string;
  percentage: number;
  description?: string;
}

interface CoveragePanelProps {
  indicators: CoverageIndicator[];
  isLoading?: boolean;
  onViewDetails?: () => void;
}

function getStatusColor(percentage: number) {
  if (percentage >= 90) return { bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200" };
  if (percentage >= 70) return { bg: "bg-yellow-50", text: "text-yellow-700", border: "border-yellow-200" };
  return { bg: "bg-red-50", text: "text-red-700", border: "border-red-200" };
}

export function CoveragePanel({ indicators, isLoading = false, onViewDetails }: CoveragePanelProps) {
  if (isLoading) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-900">Cobertura de Dados</h3>
          <BarChart3 size={20} className="text-slate-400" />
        </div>
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-12 animate-pulse rounded-lg bg-slate-100" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">Cobertura de Dados</h3>
          <p className="mt-1 text-xs text-slate-500">Qualidade e completude dos dados por módulo</p>
        </div>
        <BarChart3 size={20} className="text-slate-400" />
      </div>

      <div className="space-y-3">
        {indicators.map((indicator) => {
          const colors = getStatusColor(indicator.percentage);
          return (
            <div key={indicator.label} className={`rounded-lg border ${colors.border} ${colors.bg} p-3`}>
              <div className="flex items-center justify-between gap-2">
                <div className="flex-1">
                  <p className={`text-sm font-medium ${colors.text}`}>{indicator.label}</p>
                  {indicator.description && (
                    <p className={`mt-0.5 text-xs ${colors.text} opacity-75`}>{indicator.description}</p>
                  )}
                </div>
                <div className="flex-shrink-0">
                  <p className={`text-lg font-bold ${colors.text}`}>{indicator.percentage}%</p>
                </div>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
                <div
                  className={`h-full transition-all duration-500 ${
                    indicator.percentage >= 90
                      ? "bg-emerald-500"
                      : indicator.percentage >= 70
                        ? "bg-yellow-500"
                        : "bg-red-500"
                  }`}
                  style={{ width: `${indicator.percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {onViewDetails && (
        <Button
          variant="ghost"
          size="sm"
          className="mt-4 w-full text-slate-700 hover:text-slate-900"
          onClick={onViewDetails}
        >
          <LinkIcon size={14} className="mr-1" />
          Ver painel completo
        </Button>
      )}
    </div>
  );
}
