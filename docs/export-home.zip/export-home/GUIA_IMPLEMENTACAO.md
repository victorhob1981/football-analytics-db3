# 📋 Guia de Implementação - Página Home Modernizada

Este guia mostra como integrar a página Home e os componentes novos no seu projeto.

## 📁 Estrutura de Arquivos

```
seu-projeto/
├── src/
│   ├── pages/
│   │   └── Home.tsx              ← NOVO
│   ├── components/
│   │   ├── GlobalFilterBar.tsx   ← NOVO
│   │   ├── InsightFeed.tsx       ← NOVO
│   │   ├── CoveragePanel.tsx     ← NOVO
│   │   ├── Sparkline.tsx         ← NOVO
│   │   └── ui/
│   │       └── button.tsx        (já existe)
│   └── index.css                 ← MODIFICAR
└── ...
```

## 🔧 Passo a Passo

### 1. Copiar Arquivos

Copie os seguintes arquivos para seu projeto:

```bash
# Página Home
cp pages/Home.tsx seu-projeto/src/pages/

# Componentes
cp components/GlobalFilterBar.tsx seu-projeto/src/components/
cp components/InsightFeed.tsx seu-projeto/src/components/
cp components/CoveragePanel.tsx seu-projeto/src/components/
cp components/Sparkline.tsx seu-projeto/src/components/
```

### 2. Atualizar index.css

Você precisa atualizar a paleta de cores no seu `index.css` para o tema escuro. Procure pela seção `.dark {` e substitua pelos valores abaixo:

```css
.dark {
  --primary: #10B981;
  --primary-foreground: #F0FDF4;
  --sidebar-primary: #10B981;
  --sidebar-primary-foreground: #F0FDF4;
  --background: #0F172A;
  --foreground: #F1F5F9;
  --card: #1E293B;
  --card-foreground: #F1F5F9;
  --popover: #1E293B;
  --popover-foreground: #F1F5F9;
  --secondary: #334155;
  --secondary-foreground: #F1F5F9;
  --muted: #475569;
  --muted-foreground: #CBD5E1;
  --accent: #F97316;
  --accent-foreground: #0F172A;
  --destructive: #EF4444;
  --destructive-foreground: #0F172A;
  --border: #334155;
  --input: #475569;
  --ring: #10B981;
  --chart-1: #06B6D4;
  --chart-2: #10B981;
  --chart-3: #1E40AF;
  --chart-4: #F97316;
  --chart-5: #EC4899;
  --sidebar: #1E293B;
  --sidebar-foreground: #F1F5F9;
  --sidebar-accent: #334155;
  --sidebar-accent-foreground: #F1F5F9;
  --sidebar-border: #334155;
  --sidebar-ring: #10B981;
}
```

### 3. Atualizar App.tsx

Mude o tema padrão para `dark`:

```tsx
<ThemeProvider
  defaultTheme="dark"  // ← Mude de "light" para "dark"
  // switchable
>
```

### 4. Adicionar Classe CSS para KPI Cards

Adicione a seguinte classe ao seu `index.css` (na seção `@layer components`):

```css
@layer components {
  .stat-card {
    @apply rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-sm transition-all;
    border-left-width: 4px;
  }

  .stat-card.hover-lift {
    @apply hover:shadow-lg hover:scale-105;
  }
}
```

### 5. Verificar Dependências

Certifique-se que seu projeto tem as seguintes dependências instaladas:

```json
{
  "dependencies": {
    "react": "^19.2.1",
    "react-dom": "^19.2.1",
    "recharts": "^2.15.2",
    "lucide-react": "^0.453.0",
    "@radix-ui/react-select": "^2.2.6",
    "tailwindcss": "^4.1.14"
  }
}
```

Se alguma estiver faltando, instale com:

```bash
npm install recharts lucide-react @radix-ui/react-select
```

### 6. Atualizar Rotas (App.tsx)

Certifique-se que a rota `/` aponta para o componente `Home`:

```tsx
import Home from "./pages/Home";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      {/* ... outras rotas */}
    </Switch>
  );
}
```

## 🔌 Integração com sua BFF

Os dados estão mockados. Para conectar com sua BFF:

### 1. Criar um Hook de Dados

Crie um arquivo `src/hooks/useHomeData.ts`:

```tsx
import { useState, useEffect } from "react";
import { GlobalFilters } from "@/components/GlobalFilterBar";

export function useHomeData(filters: GlobalFilters) {
  const [kpiData, setKpiData] = useState(null);
  const [teamsData, setTeamsData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Exemplo: chamada à sua BFF
        const response = await fetch(
          `/api/home?competition=${filters.competition}&season=${filters.season}`
        );
        const data = await response.json();
        
        setKpiData(data.kpi);
        setTeamsData(data.teams);
      } catch (error) {
        console.error("Erro ao buscar dados:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [filters]);

  return { kpiData, teamsData, isLoading };
}
```

### 2. Usar o Hook na Home.tsx

```tsx
import { useHomeData } from "@/hooks/useHomeData";

export default function Home() {
  const [filters, setFilters] = useState<GlobalFilters>({...});
  const { kpiData, teamsData, isLoading } = useHomeData(filters);

  // Usar kpiData, teamsData, isLoading no lugar dos dados mockados
}
```

## 🎨 Customização

### Mudar Cores

Edite as cores no `.dark {}` do `index.css`:

- `--primary`: Cor primária (verde esmeralda)
- `--accent`: Cor de destaque (laranja)
- `--background`: Cor de fundo (azul escuro)

### Mudar Tipografia

Adicione fontes customizadas no `index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=Outfit:wght@500;600&display=swap" rel="stylesheet" />
```

E atualize o `index.css`:

```css
:root {
  --font-display: "Poppins", sans-serif;
  --font-heading: "Outfit", sans-serif;
  --font-body: "Inter", sans-serif;
}

h1, h2, h3 {
  font-family: var(--font-display);
}
```

## ✅ Checklist

- [ ] Copiei os 5 arquivos (Home.tsx + 4 componentes)
- [ ] Atualizei o `.dark {}` no index.css
- [ ] Mudei `defaultTheme` para "dark" em App.tsx
- [ ] Adicionei as classes `.stat-card` no index.css
- [ ] Verifiquei as dependências
- [ ] Testei a página no navegador
- [ ] Conectei com a BFF (opcional, mas recomendado)

## 🆘 Troubleshooting

**Erro: "Cannot find module '@/components/GlobalFilterBar'"**
- Verifique se o arquivo está em `src/components/GlobalFilterBar.tsx`
- Certifique-se que o alias `@` está configurado em `vite.config.ts` ou `tsconfig.json`

**Página fica em branco**
- Abra o console do navegador (F12) e procure por erros
- Verifique se o ThemeProvider está com `defaultTheme="dark"`

**Gráficos não aparecem**
- Instale recharts: `npm install recharts`
- Verifique se o ResponsiveContainer tem width/height corretos

## 📚 Documentação dos Componentes

### GlobalFilterBar
Barra de filtros sticky no topo. Props:
- `filters: GlobalFilters` - Estado dos filtros
- `onFiltersChange: (filters: GlobalFilters) => void` - Callback ao mudar filtros

### InsightFeed
Feed de insights ordenados por severidade. Props:
- `insights: Insight[]` - Array de insights
- `isLoading?: boolean` - Estado de carregamento

### CoveragePanel
Painel de cobertura de dados. Props:
- `indicators: CoverageIndicator[]` - Array de indicadores
- `isLoading?: boolean` - Estado de carregamento
- `onViewDetails?: () => void` - Callback ao clicar em "Ver painel completo"

### Sparkline
Gráfico de linha compacto. Props:
- `data: Array<{ value: number }>` - Dados
- `color?: string` - Cor da linha (hex)
- `height?: number` - Altura em pixels

## 🚀 Próximos Passos

1. Integre com sua BFF
2. Crie as outras páginas (`/clubs`, `/players`, `/audit`) mantendo a mesma linguagem visual
3. Implemente filtros funcionais que atualizam os dados
4. Adicione autenticação se necessário

Boa sorte! 🎉
