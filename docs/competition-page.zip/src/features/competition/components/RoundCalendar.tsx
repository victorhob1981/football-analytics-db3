"use client";

import Link from "next/link";

import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { formatDate } from "@/shared/utils/formatters";
import type { MatchStatus, RoundMatchItem } from "@/features/competition/types";

// ─── Status badge ─────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<
  MatchStatus,
  { label: string; classes: string }
> = {
  finished: { label: "Encerrada", classes: "bg-slate-100 text-slate-500" },
  scheduled: { label: "Agendada", classes: "bg-sky-50 text-sky-600" },
  live: { label: "Ao vivo", classes: "bg-emerald-50 text-emerald-600 animate-pulse" },
  cancelled: { label: "Cancelada", classes: "bg-rose-50 text-rose-500" },
};

function StatusBadge({ status }: { status: MatchStatus | null | undefined }) {
  if (!status) return null;
  const cfg = STATUS_CONFIG[status];
  return (
    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${cfg.classes}`}>
      {cfg.label}
    </span>
  );
}

// ─── Match card ───────────────────────────────────────────────────────────────

function MatchCard({ match }: { match: RoundMatchItem }) {
  const isFinished = match.status === "finished";
  const hasScore = match.homeScore != null && match.awayScore != null;

  return (
    <Link
      className="block rounded-lg border border-slate-200 bg-white p-3 no-underline transition-colors hover:border-emerald-300 hover:bg-emerald-50"
      href={`/matches/${match.matchId}`}
    >
      {/* Date + status */}
      <div className="mb-2 flex items-center justify-between gap-2">
        <span className="text-xs text-slate-400">
          {match.kickoffAt ? formatDate(match.kickoffAt) : "—"}
        </span>
        <StatusBadge status={match.status} />
      </div>

      {/* Teams + score */}
      <div className="flex items-center justify-between gap-2">
        {/* Home */}
        <span
          className={`truncate text-sm font-medium ${
            isFinished && hasScore && (match.homeScore ?? 0) > (match.awayScore ?? 0)
              ? "text-slate-900"
              : "text-slate-600"
          }`}
        >
          {match.homeTeamName ?? "—"}
        </span>

        {/* Score */}
        <span className="shrink-0 rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 font-mono text-sm font-bold text-slate-800 tabular-nums">
          {hasScore ? `${match.homeScore} – ${match.awayScore}` : "vs"}
        </span>

        {/* Away */}
        <span
          className={`truncate text-right text-sm font-medium ${
            isFinished && hasScore && (match.awayScore ?? 0) > (match.homeScore ?? 0)
              ? "text-slate-900"
              : "text-slate-600"
          }`}
        >
          {match.awayTeamName ?? "—"}
        </span>
      </div>
    </Link>
  );
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function CalendarSkeleton() {
  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          className="rounded-lg border border-slate-200 bg-white p-3 space-y-2"
          key={i}
        >
          <LoadingSkeleton height={12} width="40%" />
          <div className="flex items-center justify-between gap-2">
            <LoadingSkeleton height={14} width="35%" />
            <LoadingSkeleton height={24} width={48} />
            <LoadingSkeleton height={14} width="35%" />
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

type RoundCalendarProps = {
  matches: RoundMatchItem[];
  roundLabel?: string;
  loading?: boolean;
};

export function RoundCalendar({
  matches,
  roundLabel,
  loading = false,
}: RoundCalendarProps) {
  if (loading) return <CalendarSkeleton />;

  if (matches.length === 0) {
    return (
      <EmptyState
        description="Nenhuma partida encontrada para esta rodada."
        title="Sem partidas"
      />
    );
  }

  return (
    <div className="space-y-2">
      {roundLabel ? (
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
          Partidas — {roundLabel}
        </p>
      ) : null}
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {matches.map((match) => (
          <MatchCard key={match.matchId} match={match} />
        ))}
      </div>
    </div>
  );
}
