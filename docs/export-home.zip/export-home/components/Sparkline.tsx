import { LineChart, Line, ResponsiveContainer } from "recharts";

interface SparklineProps {
  data: Array<{ value: number }>;
  color?: string;
  height?: number;
}

export function Sparkline({ data, color = "#10B981", height = 24 }: SparklineProps) {
  if (!data || data.length === 0) {
    return <div className="h-6 w-16 bg-slate-100" />;
  }

  return (
    <ResponsiveContainer width={64} height={height}>
      <LineChart data={data}>
        <Line
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={1.5}
          dot={false}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
