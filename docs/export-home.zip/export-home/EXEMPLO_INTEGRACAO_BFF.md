# 🔌 Exemplo: Integração com BFF

Este arquivo mostra como conectar a página Home com sua BFF.

## 1. Criar Hook de Dados

Crie `src/hooks/useHomeData.ts`:

```typescript
import { useState, useEffect } from "react";
import { GlobalFilters } from "@/components/GlobalFilterBar";

interface HomeData {
  kpi: {
    totalMatches: number;
    totalGoals: number;
    avgGoalsPerMatch: number;
    totalTeams: number;
  };
  teams: Array<{
    id: string;
    name: string;
    goalsFor: number;
    goalsAgainst: number;
    sparkline: Array<{ value: number }>;
  }>;
  standings: Array<{
    round: number;
    [teamName: string]: number | string;
  }>;
  players: Array<{
    id: string;
    name: string;
    club: string;
    goals: number;
    assists: number;
    rating: number;
    variation: number;
  }>;
  insights: Array<{
    id: string;
    severity: "critical" | "warning" | "info";
    title: string;
    description: string;
    timestamp?: string;
    action?: { label: string; href: string };
  }>;
  coverage: Array<{
    label: string;
    percentage: number;
    description?: string;
  }>;
}

export function useHomeData(filters: GlobalFilters) {
  const [data, setData] = useState<HomeData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      setError(null);

      try {
        // Construir query string baseado nos filtros
        const params = new URLSearchParams({
          competition: filters.competition,
          season: filters.season,
          timeRange: filters.timeRange,
          ...(filters.lastN && { lastN: String(filters.lastN) }),
          ...(filters.month && { month: filters.month }),
          ...(filters.startDate && { startDate: filters.startDate }),
          ...(filters.endDate && { endDate: filters.endDate }),
        });

        // Chamar sua BFF
        const response = await fetch(
          `/api/home?${params.toString()}`,
          {
            headers: {
              "Content-Type": "application/json",
              // Adicione autenticação se necessário
              // "Authorization": `Bearer ${token}`,
            },
          }
        );

        if (!response.ok) {
          throw new Error(`Erro: ${response.status} ${response.statusText}`);
        }

        const homeData: HomeData = await response.json();
        setData(homeData);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Erro desconhecido");
        console.error("Erro ao buscar dados da home:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [filters]);

  return { data, isLoading, error };
}
```

## 2. Usar o Hook na Home.tsx

Modifique seu `Home.tsx` para usar o hook:

```typescript
import { useState } from "react";
import { GlobalFilterBar, type GlobalFilters } from "@/components/GlobalFilterBar";
import { useHomeData } from "@/hooks/useHomeData";

export default function Home() {
  const [filters, setFilters] = useState<GlobalFilters>({
    competition: "serie-a",
    season: "2024",
    timeRange: "season",
    lastN: 10,
  });

  // Buscar dados da BFF
  const { data, isLoading, error } = useHomeData(filters);

  if (error) {
    return (
      <div className="dark min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <GlobalFilterBar filters={filters} onFiltersChange={setFilters} />
        <div className="mx-auto max-w-7xl px-4 py-8">
          <div className="rounded-lg border border-red-700 bg-red-900 p-6 text-red-100">
            <p className="font-semibold">Erro ao carregar dados:</p>
            <p>{error}</p>
          </div>
        </div>
      </div>
    );
  }

  // Usar dados da BFF ou fallback para mockados
  const kpiData = data?.kpi || mockKPIData;
  const teamsData = data?.teams || mockTeamsData;
  const standingsData = data?.standings || mockStandingsData;
  const playersData = data?.players || mockPlayersData;
  const insightsData = data?.insights || mockInsights;
  const coverageData = data?.coverage || mockCoverageData;

  return (
    <div className="dark min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <GlobalFilterBar filters={filters} onFiltersChange={setFilters} />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Seção 1: KPIs */}
        <div className="mb-8">
          <h2 className="mb-4 text-2xl font-bold text-slate-100">Indicadores Principais</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KPICard
              title="Partidas Disputadas"
              value={kpiData.totalMatches}
              icon={Trophy}
              color="#10B981"
              isLoading={isLoading}
            />
            {/* ... outros KPI cards */}
          </div>
        </div>

        {/* ... resto da página usando os dados da BFF */}
      </div>
    </div>
  );
}
```

## 3. Exemplo de Resposta da BFF

Sua BFF deve retornar um JSON como este:

```json
{
  "kpi": {
    "totalMatches": 380,
    "totalGoals": 1247,
    "avgGoalsPerMatch": 3.28,
    "totalTeams": 42
  },
  "teams": [
    {
      "id": "team-1",
      "name": "Time A",
      "goalsFor": 85,
      "goalsAgainst": 32,
      "sparkline": [
        { "value": 5 },
        { "value": 7 },
        { "value": 6 },
        { "value": 8 },
        { "value": 9 },
        { "value": 8 }
      ]
    }
  ],
  "standings": [
    {
      "round": 1,
      "Time A": 3,
      "Time B": 1,
      "Time C": 0,
      "Time D": 1,
      "Time E": 0,
      "Time F": 2
    }
  ],
  "players": [
    {
      "id": "p1",
      "name": "Jogador A",
      "club": "Time A",
      "goals": 24,
      "assists": 8,
      "rating": 8.2,
      "variation": 2.1
    }
  ],
  "insights": [
    {
      "id": "i1",
      "severity": "critical",
      "title": "Queda ofensiva detectada",
      "description": "Time A reduziu média de gols em 35% nas últimas 3 rodadas",
      "timestamp": "Há 2 horas",
      "action": {
        "label": "Ver análise",
        "href": "/clubs/team-a"
      }
    }
  ],
  "coverage": [
    {
      "label": "Fixtures com eventos",
      "percentage": 95,
      "description": "Dados de eventos registrados"
    }
  ]
}
```

## 4. Endpoints Esperados

Sua BFF deve ter um endpoint como:

```
GET /api/home?competition=serie-a&season=2024&timeRange=season&lastN=10
```

Que retorna os dados acima.

## 5. Tratamento de Erros

O hook já trata erros básicos. Para casos específicos:

```typescript
const { data, isLoading, error } = useHomeData(filters);

if (error) {
  // Mostrar mensagem de erro
  return <ErrorComponent message={error} />;
}

if (isLoading) {
  // Mostrar skeleton loaders
  return <LoadingComponent />;
}

// Renderizar com dados
```

## 6. Cache e Revalidação

Para adicionar cache:

```typescript
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos

export function useHomeData(filters: GlobalFilters) {
  const [cache, setCache] = useState<{ data: HomeData; timestamp: number } | null>(null);

  // ... resto do hook

  useEffect(() => {
    // Verificar cache
    if (cache && Date.now() - cache.timestamp < CACHE_DURATION) {
      setData(cache.data);
      return;
    }

    // Buscar dados
    fetchData();
  }, [filters]);

  // ... resto do hook
}
```

## 7. Autenticação

Se sua BFF requer autenticação:

```typescript
const response = await fetch(`/api/home?${params.toString()}`, {
  headers: {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${localStorage.getItem("token")}`,
  },
});
```

## 📚 Referência de Filtros

Os filtros suportados são:

- `competition`: "serie-a", "serie-b", "copa-br", "libertadores"
- `season`: "2024", "2023", "2022"
- `timeRange`: "season", "lastN", "month", "interval"
- `lastN`: 5, 10, 15, 20 (quando timeRange = "lastN")
- `month`: "2024-01", "2024-02", etc (quando timeRange = "month")
- `startDate`: "2024-01-01" (quando timeRange = "interval")
- `endDate`: "2024-12-31" (quando timeRange = "interval")

## 🚀 Próximos Passos

1. Implemente o hook `useHomeData` no seu projeto
2. Crie o endpoint `/api/home` na sua BFF
3. Teste a integração
4. Adicione cache se necessário
5. Implemente tratamento de erros mais robusto

Boa sorte! 🎉
