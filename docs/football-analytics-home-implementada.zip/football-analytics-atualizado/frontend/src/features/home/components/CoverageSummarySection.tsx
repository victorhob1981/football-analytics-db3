"use client";

import Link from "next/link";

import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { formatPercentage } from "@/shared/utils/formatters";
import { useCoverageSummary } from "@/features/home/hooks";
import type { CoverageLevel, CoverageModuleItem } from "@/features/home/types";

const LEVEL_CONFIG: Record<
  CoverageLevel,
  { bar: string; text: string; dot: string; bg: string }
> = {
  high: {
    bar: "bg-emerald-500",
    text: "text-emerald-700",
    dot: "bg-emerald-500",
    bg: "bg-emerald-50",
  },
  partial: {
    bar: "bg-amber-400",
    text: "text-amber-700",
    dot: "bg-amber-400",
    bg: "bg-amber-50",
  },
  low: {
    bar: "bg-rose-500",
    text: "text-rose-700",
    dot: "bg-rose-500",
    bg: "bg-rose-50",
  },
};

function CoverageBar({ module: mod }: { module: CoverageModuleItem }) {
  const cfg = LEVEL_CONFIG[mod.level];
  const pct = Math.min(100, Math.max(0, mod.percentage));

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <span className={`h-2 w-2 rounded-full ${cfg.dot}`} />
          <span className="text-sm text-slate-700">{mod.label}</span>
        </div>
        <span className={`text-xs font-semibold tabular-nums ${cfg.text}`}>
          {formatPercentage(pct, 0)}
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
        <div
          className={`h-full rounded-full transition-all duration-500 ${cfg.bar}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function CoverageSkeletons() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div className="space-y-1" key={i}>
          <div className="flex justify-between">
            <LoadingSkeleton height={14} width="40%" />
            <LoadingSkeleton height={14} width={32} />
          </div>
          <LoadingSkeleton height={6} />
        </div>
      ))}
    </div>
  );
}

export function CoverageSummarySection() {
  const { data, isLoading, isEmpty } = useCoverageSummary();

  if (isLoading) return <CoverageSkeletons />;

  if (isEmpty || !data || data.modules.length === 0) {
    return (
      <EmptyState
        description="Dados de cobertura não disponíveis no momento."
        title="Sem dados de cobertura"
      />
    );
  }

  return (
    <div className="space-y-3">
      {data.modules.map((mod) => (
        <CoverageBar key={mod.label} module={mod} />
      ))}
      <div className="pt-1 text-right">
        <Link
          className="text-xs font-medium text-emerald-700 no-underline hover:underline"
          href="/audit"
        >
          Painel completo de auditoria →
        </Link>
      </div>
    </div>
  );
}
