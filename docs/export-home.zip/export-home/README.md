# 🏠 Página Home Modernizada - Componentes

Este pacote contém a página Home modernizada e 4 componentes reutilizáveis para seu dashboard de futebol.

## 📦 O que está incluído

### Página
- **Home.tsx** - Página executiva com 6 seções (KPIs, Top Ataques/Defesas, Evolução, Top Jogadores, Insights, Cobertura)

### Componentes
- **GlobalFilterBar.tsx** - Barra de filtros sticky (competição, temporada, recorte temporal)
- **InsightFeed.tsx** - Feed de insights ordenados por severidade (crítico, aviso, info)
- **CoveragePanel.tsx** - Painel de indicadores de cobertura de dados com progress bars
- **Sparkline.tsx** - Gráfico de linha compacto para tendências

## 🎨 Design

- **Tema**: Escuro (dark mode)
- **Paleta**: Verde esmeralda (#10B981), Azul (#1E40AF), Laranja (#F97316), Ciano (#06B6D4)
- **Tipografia**: Poppins (títulos), Outfit (subtítulos), Inter (corpo)
- **Componentes**: shadcn/ui + Tailwind CSS 4

## 🚀 Quick Start

1. Copie os arquivos para seu projeto
2. Atualize o `index.css` com a paleta de cores (veja GUIA_IMPLEMENTACAO.md)
3. Mude `defaultTheme` para "dark" em `App.tsx`
4. Instale dependências se necessário: `npm install recharts`
5. Pronto! A página deve aparecer em `/`

## 📖 Documentação Completa

Veja **GUIA_IMPLEMENTACAO.md** para:
- Passo a passo detalhado
- Como integrar com sua BFF
- Customização de cores e tipografia
- Troubleshooting

## 📋 Estrutura de Dados

### GlobalFilters
```typescript
{
  competition: string;      // "serie-a", "serie-b", etc
  season: string;           // "2024", "2023", etc
  timeRange: "season" | "lastN" | "month" | "interval";
  lastN?: number;           // 5, 10, 15, 20
  month?: string;           // "2024-01", "2024-02", etc
  startDate?: string;       // "2024-01-01"
  endDate?: string;         // "2024-12-31"
}
```

### Insight
```typescript
{
  id: string;
  severity: "critical" | "warning" | "info";
  title: string;
  description: string;
  timestamp?: string;
  action?: { label: string; href: string };
}
```

### CoverageIndicator
```typescript
{
  label: string;
  percentage: number;       // 0-100
  description?: string;
}
```

## 🔧 Dependências Necessárias

```json
{
  "recharts": "^2.15.2",
  "lucide-react": "^0.453.0",
  "@radix-ui/react-select": "^2.2.6",
  "tailwindcss": "^4.1.14"
}
```

## 💡 Dicas

- Os dados estão mockados - substitua pelos dados reais da sua BFF
- Use o hook `useTheme()` para implementar toggle de tema
- Os componentes são totalmente reutilizáveis em outras páginas
- Mantenha a paleta de cores consistente em todo o dashboard

## ❓ Dúvidas?

Consulte o **GUIA_IMPLEMENTACAO.md** para mais detalhes!
