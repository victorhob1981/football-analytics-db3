import { useQueryWithCoverage } from "@/shared/hooks/useQueryWithCoverage";

import { competitionQueryKeys } from "@/features/competition/queryKeys";
import { fetchRounds } from "@/features/competition/services";
import type { RoundItem } from "@/features/competition/types";
import { useCompetitionFilters } from "./useCompetitionFilters";

const STALE_TIME_MS = 60 * 60 * 1000; // rounds don't change — 1h
const GC_TIME_MS = 2 * 60 * 60 * 1000;

export function useRounds(competitionId: string) {
  const filters = useCompetitionFilters();

  return useQueryWithCoverage<RoundItem[]>({
    queryKey: competitionQueryKeys.rounds(competitionId, filters),
    queryFn: () => fetchRounds(competitionId, filters),
    enabled: competitionId.length > 0,
    staleTime: STALE_TIME_MS,
    gcTime: GC_TIME_MS,
    isDataEmpty: (data) => data.length === 0,
  });
}
