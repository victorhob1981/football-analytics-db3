import { buildQueryKey } from "@/shared/utils/queryKeys";

import type {
  CompetitionGlobalFilters,
  CompetitionLocalFilters,
} from "@/features/competition/types";

type Filters = CompetitionGlobalFilters & CompetitionLocalFilters;

export const competitionQueryKeys = {
  all: () => buildQueryKey("competition"),
  rounds: (competitionId: string, filters: CompetitionGlobalFilters) =>
    buildQueryKey("competition", "rounds", competitionId, filters),
  stages: (competitionId: string, filters: CompetitionGlobalFilters) =>
    buildQueryKey("competition", "stages", competitionId, filters),
  standings: (competitionId: string, filters: Filters) =>
    buildQueryKey("competition", "standings", competitionId, filters),
  evolution: (competitionId: string, filters: Filters) =>
    buildQueryKey("competition", "evolution", competitionId, filters),
  calendar: (competitionId: string, filters: Filters) =>
    buildQueryKey("competition", "calendar", competitionId, filters),
} as const;
