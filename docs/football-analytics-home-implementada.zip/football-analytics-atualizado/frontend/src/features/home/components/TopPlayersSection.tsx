"use client";

import Link from "next/link";

import { EmptyState } from "@/shared/components/feedback/EmptyState";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import { formatNumber } from "@/shared/utils/formatters";
import { useTopPlayers } from "@/features/home/hooks";
import type { TopPlayerItem } from "@/features/home/types";

function PlayerRow({ player, rank }: { player: TopPlayerItem; rank: number }) {
  const goalAssist =
    (player.goals ?? 0) + (player.assists ?? 0);

  return (
    <tr className="border-b border-slate-100 last:border-0 hover:bg-slate-50">
      <td className="py-2.5 pl-3 pr-2 text-xs font-medium text-slate-400">{rank}</td>
      <td className="py-2.5 pr-3">
        <Link
          className="block truncate text-sm font-medium text-slate-800 no-underline hover:text-emerald-700"
          href={`/players/${player.playerId}`}
        >
          {player.playerName}
        </Link>
        {player.teamName ? (
          <span className="text-xs text-slate-400">{player.teamName}</span>
        ) : null}
      </td>
      <td className="py-2.5 pr-3 text-right text-sm tabular-nums text-slate-700">
        {player.goals ?? "-"}
      </td>
      <td className="py-2.5 pr-3 text-right text-sm tabular-nums text-slate-700">
        {player.assists ?? "-"}
      </td>
      <td className="py-2.5 pr-3 text-right text-sm tabular-nums font-semibold text-emerald-700">
        {formatNumber(goalAssist)}
      </td>
      <td className="py-2.5 pr-3 text-right text-sm tabular-nums text-slate-500">
        {player.rating != null ? formatNumber(player.rating, 2) : "-"}
      </td>
    </tr>
  );
}

function TableSkeleton() {
  return (
    <div className="rounded-lg border border-slate-200 bg-white">
      <div className="border-b border-slate-100 px-4 py-3">
        <LoadingSkeleton height={14} width="30%" />
      </div>
      <div className="divide-y divide-slate-100 px-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div className="flex items-center gap-3 py-2.5" key={i}>
            <LoadingSkeleton height={12} width={16} />
            <LoadingSkeleton height={14} width="45%" />
            <div className="ml-auto flex gap-4">
              <LoadingSkeleton height={12} width={28} />
              <LoadingSkeleton height={12} width={28} />
              <LoadingSkeleton height={12} width={28} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function TopPlayersSection() {
  const { data, isLoading, isEmpty } = useTopPlayers();

  if (isLoading) return <TableSkeleton />;

  if (isEmpty || !data || data.items.length === 0) {
    return (
      <EmptyState
        description="Nenhum dado de jogadores disponível para o recorte atual."
        title="Sem dados de jogadores"
      />
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold uppercase tracking-wide text-slate-500">
              <th className="py-2.5 pl-3 pr-2 w-8">#</th>
              <th className="py-2.5 pr-3">Jogador</th>
              <th className="py-2.5 pr-3 text-right">G</th>
              <th className="py-2.5 pr-3 text-right">A</th>
              <th className="py-2.5 pr-3 text-right">G+A</th>
              <th className="py-2.5 pr-3 text-right">Rating</th>
            </tr>
          </thead>
          <tbody>
            {data.items.map((player, i) => (
              <PlayerRow key={player.playerId} player={player} rank={i + 1} />
            ))}
          </tbody>
        </table>
      </div>
      <div className="border-t border-slate-100 px-4 py-2.5 text-right">
        <Link
          className="text-xs font-medium text-emerald-700 no-underline hover:underline"
          href="/players"
        >
          Ver todos os jogadores →
        </Link>
      </div>
    </div>
  );
}
