"use client";

import { CoverageBadge } from "@/shared/components/coverage/CoverageBadge";
import { LoadingSkeleton } from "@/shared/components/feedback/LoadingSkeleton";
import type { StageItem } from "@/features/competition/types";

type StageFilterProps = {
  stages: StageItem[];
  selectedStageId: string | null;
  onSelect: (stageId: string | null) => void;
  loading?: boolean;
};

export function StageFilter({
  stages,
  selectedStageId,
  onSelect,
  loading = false,
}: StageFilterProps) {
  if (loading) {
    return <LoadingSkeleton height={32} width={160} />;
  }

  if (stages.length === 0) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm text-slate-400">Fases:</span>
        <CoverageBadge
          coverage={{ status: "partial", label: "Cobertura de fase indisponível" }}
        />
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <label
        className="text-sm font-medium text-slate-600"
        htmlFor="stage-filter"
      >
        Fase:
      </label>
      <select
        className="rounded-md border border-slate-200 bg-white px-2 py-1 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-300"
        id="stage-filter"
        onChange={(e) => onSelect(e.target.value === "" ? null : e.target.value)}
        value={selectedStageId ?? ""}
      >
        <option value="">Todas as fases</option>
        {stages.map((stage) => (
          <option key={stage.stageId} value={stage.stageId}>
            {stage.label}
          </option>
        ))}
      </select>
    </div>
  );
}
