import type { VenueFilter } from "@/shared/types/filters.types";

// ─── Dimensions ───────────────────────────────────────────────────────────────

export interface RoundItem {
  roundId: string;
  roundNumber: number;
  label: string;
  isCurrentRound?: boolean;
}

export interface StageItem {
  stageId: string;
  label: string;
}

// ─── Standings snapshot ───────────────────────────────────────────────────────

export type StandingZone = "title" | "continental" | "relegation" | null;

export interface StandingRow {
  position: number;
  teamId: string;
  teamName: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDiff: number;
  points: number;
  /** Last 5 results: "W" | "D" | "L" */
  form?: string[];
  zone?: StandingZone;
}

export interface StandingsSnapshotData {
  roundId: string;
  roundLabel: string;
  rows: StandingRow[];
}

// ─── Standings evolution ──────────────────────────────────────────────────────

export interface EvolutionPoint {
  roundLabel: string;
  [teamName: string]: string | number;
}

export type EvolutionMetric = "points" | "position";

export interface StandingsEvolutionData {
  series: EvolutionPoint[];
  teamNames: string[];
}

// ─── Round calendar ───────────────────────────────────────────────────────────

export type MatchStatus = "finished" | "scheduled" | "live" | "cancelled";

export interface RoundMatchItem {
  matchId: string;
  homeTeamId?: string | null;
  homeTeamName?: string | null;
  awayTeamId?: string | null;
  awayTeamName?: string | null;
  homeScore?: number | null;
  awayScore?: number | null;
  status?: MatchStatus | null;
  kickoffAt?: string | null;
}

export interface RoundCalendarData {
  roundId: string;
  roundLabel: string;
  matches: RoundMatchItem[];
}

// ─── Filters ─────────────────────────────────────────────────────────────────

export interface CompetitionGlobalFilters {
  competitionId?: string | null;
  seasonId?: string | null;
  roundId?: string | null;
  venue?: VenueFilter;
  lastN?: number | null;
  dateRangeStart?: string | null;
  dateRangeEnd?: string | null;
}

export interface CompetitionLocalFilters {
  stageId?: string | null;
}
