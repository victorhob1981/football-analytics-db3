import { AlertCircle, AlertTriangle, Info } from "lucide-react";

export type InsightSeverity = "critical" | "warning" | "info";

export interface Insight {
  id: string;
  severity: InsightSeverity;
  title: string;
  description: string;
  timestamp?: string;
  action?: {
    label: string;
    href: string;
  };
}

interface InsightFeedProps {
  insights: Insight[];
  isLoading?: boolean;
}

function getSeverityConfig(severity: InsightSeverity) {
  switch (severity) {
    case "critical":
      return {
        bgColor: "bg-red-50",
        borderColor: "border-red-200",
        textColor: "text-red-900",
        labelColor: "text-red-700",
        icon: AlertCircle,
        label: "Crítico",
      };
    case "warning":
      return {
        bgColor: "bg-yellow-50",
        borderColor: "border-yellow-200",
        textColor: "text-yellow-900",
        labelColor: "text-yellow-700",
        icon: AlertTriangle,
        label: "Aviso",
      };
    case "info":
      return {
        bgColor: "bg-blue-50",
        borderColor: "border-blue-200",
        textColor: "text-blue-900",
        labelColor: "text-blue-700",
        icon: Info,
        label: "Info",
      };
  }
}

export function InsightFeed({ insights, isLoading = false }: InsightFeedProps) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-20 animate-pulse rounded-lg bg-slate-100" />
        ))}
      </div>
    );
  }

  if (insights.length === 0) {
    return (
      <div className="rounded-lg border border-slate-200 bg-slate-50 p-6 text-center">
        <Info size={32} className="mx-auto mb-2 text-slate-400" />
        <p className="text-sm text-slate-600">Nenhum insight disponível no momento</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {insights.map((insight) => {
        const config = getSeverityConfig(insight.severity);
        const IconComponent = config.icon;

        return (
          <div
            key={insight.id}
            className={`rounded-lg border ${config.borderColor} ${config.bgColor} p-4 transition-all hover:shadow-md`}
          >
            <div className="flex gap-3">
              <div className="flex-shrink-0 pt-0.5">
                <IconComponent size={18} className={config.labelColor} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className={`text-sm font-semibold ${config.textColor}`}>{insight.title}</p>
                    <p className={`mt-1 text-xs ${config.labelColor}`}>{insight.description}</p>
                  </div>
                  <span className={`text-xs font-medium ${config.labelColor} whitespace-nowrap`}>
                    {config.label}
                  </span>
                </div>
                {insight.action && (
                  <a
                    href={insight.action.href}
                    className={`mt-2 inline-block text-xs font-medium ${config.labelColor} hover:underline`}
                  >
                    {insight.action.label} →
                  </a>
                )}
                {insight.timestamp && (
                  <p className={`mt-2 text-xs ${config.labelColor} opacity-70`}>{insight.timestamp}</p>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
